package Assignment;

public class MainClass {
    public static void main(String[] args) {
        Shape[] shapes = new Shape[5];
        shapes[0] = new Rectangle(4, 8);
        shapes[1] = new Circle(7);
        shapes[2] = new Square(4);
        shapes[3] = new Circle(6);
        shapes[4] = new Rectangle(5, 10);

        printTotal(shapes);
    }

    public static void printTotal(Shape[] shapes) {
        double totalArea = 0.0;
        double totalPerimeter = 0.0;

        for (Shape shape : shapes) {
            totalArea += shape.calculateArea();
            totalPerimeter += shape.calculatePerimeter();
        }
        System.out.println("Total Area of all shape:" + totalArea);
        System.out.println("Total primeter of all shape: " + totalPerimeter);
    }
}
