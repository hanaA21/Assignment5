package Assignment;

public class Shape {
    double calculateArea(){
        return 0.0;
    }
    double calculatePerimeter(){
        return 0.0;
    }
}

