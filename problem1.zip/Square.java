package Assignment;

public class Square extends Rectangle {
    Square(double side) {
        super(side, side);
    }
}
