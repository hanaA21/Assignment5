package Assignment;

import java.time.LocalDate;

public class Secretary extends DeptEmployee{
    private double overTimeHours;
    public Secretary(String name, LocalDate hireDate, int overTimeHours){
        super(name,hireDate);
        this.overTimeHours=overTimeHours;
    }
    public double getOverTimeHours(){
        return overTimeHours;
    }
    @Override
    public double computeSalary(){
        return super.computeSalary() + 12 * overTimeHours;
    }
}
