package Assignment;
import java.time.LocalDate;
import java.util.Scanner;
public class Main {
    public static void main(String[] args){
        Professor professor1 = new Professor("Matt Steven", LocalDate.of(2000,6,8),9);
        Professor professor2 = new Professor("Alex Bob",LocalDate.of(2001,9,16),10);
        Professor professor3 = new Professor("John Andrew",LocalDate.of(2002,12,27),11);

        Secretary secretary1 = new Secretary("Kelly Smith",LocalDate.of(2006,8,22),5);
        Secretary secretary2 = new Secretary("Alice Brown",LocalDate.of(2011,9,28),13);

        DeptEmployee[] employees = {professor1,professor2,professor3,secretary1,secretary2};

        Scanner scan = new Scanner(System.in);
        System.out.print("Do you wish to see the sum of all Professor and Secretary salaries? (Y/N): ");
        String userInput = scan.next();

        if (userInput.equalsIgnoreCase("Y")) {
            double totalSalary = 0.0;

            for (DeptEmployee employee : employees) {
                totalSalary += employee.computeSalary();
            }

            System.out.println("Total salary of all Professor and Secretary: $" + totalSalary);
        } else {
            System.out.println("Thank you for using the application.");
        }
    }
}


